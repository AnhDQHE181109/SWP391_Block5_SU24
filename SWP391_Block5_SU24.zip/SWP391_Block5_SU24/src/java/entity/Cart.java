/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.math.BigDecimal;
import java.util.Date;

public class Cart {
    private int cartId;
    private int customerId;
    private int productId;
    private int colorId;
    private int sizeId;
    private int quantity;
    private BigDecimal discount;
    private Date dateAdded;

    // Getters and setters
}