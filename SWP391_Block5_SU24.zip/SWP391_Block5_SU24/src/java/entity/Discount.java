/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.math.BigDecimal;

public class Discount {
    private int discountId;
    private int productId;
    private int colorId;
    private int sizeId;
    private BigDecimal discountAmount;

    // Getters and setters
}
