/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.math.BigDecimal;

public class OrderDetail {
    private int orderDetailID;
    private Integer orderID;
    private Integer productID;
    private int quantity;
    private BigDecimal salePrice;

    // Getters and setters
}