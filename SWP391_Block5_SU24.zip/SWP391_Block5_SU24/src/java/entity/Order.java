/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.util.Date;

public class Order {
    private int orderID;
    private Integer accountID;
    private Date orderDate;
    private String status;

    // Getters and setters
}
